#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cstdarg>
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
using UCRT = int (__cdecl *)(unsigned long long, char *, size_t, const char *, void *, va_list);
int fmt(int mode, char *p, size_t n, const char *f, ...) {
    va_list a; va_start(a,f);
    int k;
    if (mode == 0) k = vsnprintf(p,n,f,a);
    else if (mode == 1) k = ::_vsnprintf(p,n,f,a);
    else {
        static const auto u = reinterpret_cast<UCRT>(GetProcAddress(GetModuleHandleW(L"ucrtbase.dll"), "__stdio_common_vsprintf"));
        if (!u) return -244;
        k = u(1ULL << 1, p, n, f, nullptr, a);
    }
    va_end(a);
    return k;
}
int main(int argc, char **argv) {
    SetErrorMode(SEM_FAILCRITICALERRORS | SEM_NOGPFAULTERRORBOX);
    const int mode = argc > 1 ? atoi(argv[1]) : 0;
    LoadLibraryW(L"ucrtbase.dll");
    for (int i=0;i<100000;++i) {
        char data[128]{}, shortdata[6]{};
        const int a = fmt(mode, data, sizeof(data), "%s: %zu %.2f %lld", "probe", size_t(52914580), 1.25, -11LL);
        const int b = fmt(mode, shortdata, sizeof(shortdata), "%s", "probe-long");
        if (i == 0) std::printf("mode=%d full=%d value=%s trunc=%d last_byte=%d\n",mode,a,data,b,int(shortdata[5]));
        if (std::strcmp(data,"probe: 52914580 1.25 -11")) return 5;
    }
}
